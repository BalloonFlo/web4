package db_coonect;

import java.util.ArrayList;

public class BbsListUI {

	public static void main(String[] args) {
		
		BbsDAO dao = new BbsDAO();
		ArrayList<BbsVO> list = dao.list();
		System.out.println("�˻��� �Խù��� >> " + list.size());
		for (int i = 0; i < list.size(); i++) {
			BbsVO bag = list.get(i);
			System.out.println(bag.getNo());
			System.out.println(bag.getTitle());
			System.out.println(bag.getContent());
			System.out.println(bag.getWriter());
			System.out.println("--------------");
		}
//		for (BbsVO bag : list) {
//			System.out.println(bag.getNo());
//			System.out.println(bag.getTitle());
//			System.out.println(bag.getContent());
//			System.out.println(bag.getWriter());
//			System.out.println("--------------");
//		}
		
	}

}
