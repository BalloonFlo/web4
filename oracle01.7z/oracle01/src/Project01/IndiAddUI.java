package Project01;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Formatter;
import java.awt.event.ActionEvent;

public class IndiAddUI {
	private static JTextField t1;
	private static JTextField t2;
	private static JTextField t3;
	private static JTextField t4;
	private static JTextField t5;
	private static JTextField t6;

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.getContentPane().setBackground(Color.GREEN);
		f.setSize(700, 800);
		f.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("���� �߰�");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.BOLD, 40));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(292, 39, 158, 48);
		f.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("���");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		lblNewLabel_1.setBounds(76, 151, 100, 25);
		f.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_1_1 = new JLabel("�ٹ���");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		lblNewLabel_1_1.setBounds(76, 309, 100, 25);
		f.getContentPane().add(lblNewLabel_1_1);

		JLabel lblNewLabel_1_1_1 = new JLabel("������");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		lblNewLabel_1_1_1.setBounds(76, 228, 100, 25);
		f.getContentPane().add(lblNewLabel_1_1_1);

		JLabel lblNewLabel_1_1_1_1 = new JLabel("�߸���");
		lblNewLabel_1_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1_1.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		lblNewLabel_1_1_1_1.setBounds(76, 383, 100, 25);
		f.getContentPane().add(lblNewLabel_1_1_1_1);

		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("��ũ");
		lblNewLabel_1_1_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1_1_1.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		lblNewLabel_1_1_1_1_1.setBounds(76, 470, 100, 25);
		f.getContentPane().add(lblNewLabel_1_1_1_1_1);

		JLabel lblNewLabel_1_1_1_1_1_1 = new JLabel("�۾���(ID)");
		lblNewLabel_1_1_1_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1_1_1_1.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		lblNewLabel_1_1_1_1_1_1.setBounds(76, 541, 100, 25);
		f.getContentPane().add(lblNewLabel_1_1_1_1_1_1);

		t1 = new JTextField();
		t1.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		t1.setBounds(240, 150, 315, 26);
		f.getContentPane().add(t1);
		t1.setColumns(10);

		t2 = new JTextField();
		t2.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		t2.setColumns(10);
		t2.setBounds(240, 227, 315, 26);
		f.getContentPane().add(t2);

		t3 = new JTextField();
		t3.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		t3.setColumns(10);
		t3.setBounds(240, 308, 315, 26);
		f.getContentPane().add(t3);

		t4 = new JTextField();
		t4.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		t4.setColumns(10);
		t4.setBounds(240, 382, 315, 26);
		f.getContentPane().add(t4);

		t5 = new JTextField();
		t5.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		t5.setColumns(10);
		t5.setBounds(240, 469, 315, 26);
		f.getContentPane().add(t5);

		t6 = new JTextField();
		t6.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		t6.setColumns(10);
		t6.setBounds(240, 540, 315, 26);
		f.getContentPane().add(t6);

		JButton btnNewButton_1 = new JButton("�������");
		btnNewButton_1.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		btnNewButton_1.setBounds(34, 60, 117, 29);
		f.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("����");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String song = t1.getText();
				String singer = t2.getText();
				String album = t3.getText();
				String sdateStr = t4.getText();
				Date sdate = Date.valueOf(sdateStr);
				String link = t5.getText();
				String writer = t6.getText();
				
				IndiAddDAO dao = new IndiAddDAO();
				
				IndiAddVO bag = new IndiAddVO();
				bag.setSong(song);
				bag.setSinger(singer);
				bag.setAlbum(album);
				bag.setSdate(sdate);
				bag.setLink(link);
				bag.setWriter(writer);
				
				dao.insert(bag);
			}
		});
		btnNewButton_2.setForeground(Color.RED);
		btnNewButton_2.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		btnNewButton_2.setBounds(329, 653, 117, 29);
		f.getContentPane().add(btnNewButton_2);

		f.setVisible(true);
	}
}