package Project01;

import java.util.Date;

public class IndiAddVO {
	String song;
	String singer;
	String album;
	Date sdate;
	String link;
	String writer;

	public String getSong() {
		return song;
	}

	public void setSong(String song) {
		this.song = song;
	}

	public String getSinger() {
		return singer;
	}

	public void setSinger(String singer) {
		this.singer = singer;
	}

	public String getAlbum() {
		return album;
	}

	public void setAlbum(String album) {
		this.album = album;
	}

	public Date getSdate() {
		return sdate;
	}

	public void setSdate(Date sdate) {
		this.sdate = sdate;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	@Override
	public String toString() {
		return "BaladAddVO [song=" + song + ", singer=" + singer + ", album=" + album + ", sdate=" + sdate + ", link="
				+ link + ", writer=" + writer + "]";
	}

}