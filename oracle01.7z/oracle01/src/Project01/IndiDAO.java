package Project01;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;

import javax.xml.crypto.Data;

import db_coonect.MemberVO;

public class IndiDAO {

	public ArrayList<IndiVO> list() {
		
		ArrayList<IndiVO> list = new ArrayList<>();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
//			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("1. ����̹� ���� ����");

			String url = "jdbc:mysql://localhost:3306/school?useUnicode=true&serverTimezone=Asia/Seoul";
			String user = "root";
			String password = "1234";
//			String url = "jdbc:oracle:thin:@localhost:1521:xe";
//			String user = "scott";
//			String password = "tiger"; 
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db���� ����");

			String sql = "select * from indi";
			PreparedStatement ps = con.prepareStatement(sql);
			System.out.println("3. sql�� ���� ����.@@@@@");

			ResultSet rs = ps.executeQuery(); 
			while (rs.next()) { 
				System.out.println("�˻������ ����.");
				String song = rs.getString(1); 
				String singer = rs.getString(2);
				String album = rs.getString(3);
				Date sdate = rs.getDate(4);
				String writer  = rs.getString(7);
				System.out.println("�˻��� ���>>" + song + " " + singer + " " + album + " " + sdate + " " + writer);

				IndiVO bag = new IndiVO();
				bag.setSong(song);
				bag.setSinger(singer);
				bag.setAlbum(album);
				bag.setSdate(sdate);
				bag.setWriter(writer);
				
				list.add(bag);
			} 
			System.out.println("box(list)�� �� ������ ���� >>" + list.size());
			ps.close();
			con.close();
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
		
	}

}
