package Project01;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import java.awt.Font;
import java.util.ArrayList;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;

import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class IndiUI {
	private static JTextField t7;
	private static JTable table;
	private static JTextField t1;

	public static void main(String[] args) {

		JFrame f = new JFrame();
		f.getContentPane().setBackground(new Color(255, 255, 255));
		f.setSize(700, 800);
		f.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("MUSIC");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.BOLD, 40));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(30, 49, 147, 79);
		f.getContentPane().add(lblNewLabel);

		t1 = new JTextField();
		t1.setForeground(Color.RED);
		t1.setHorizontalAlignment(SwingConstants.CENTER);
		t1.setBounds(30, 17, 615, 46);
		f.getContentPane().add(t1);
		t1.setColumns(10);

		t7 = new JTextField();
		t7.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		t7.setText("������ �Է��ϼ���");
		t7.setHorizontalAlignment(SwingConstants.CENTER);
		t7.setBounds(234, 80, 302, 27);
		f.getContentPane().add(t7);
		t7.setColumns(10);

		JSeparator separator = new JSeparator();
		separator.setBounds(30, 181, 615, 15);
		f.getContentPane().add(separator);

		JPanel panel = new JPanel();
		panel.setBounds(30, 228, 615, 516);
		f.getContentPane().add(panel);

		String[] header = { "�뷡", "����", "�ٹ���", "�߸���", "��ũ", "�۾���" };

		IndiAddDAO dao = new IndiAddDAO();
		ArrayList<IndiAddVO> list = dao.list();

		Object[][] all = new Object[list.size()][6];

		for (int i = 0; i < list.size(); i++) {
			IndiAddVO bag = list.get(i);
			all[i][0] = bag.getSong();
			all[i][1] = bag.getSinger();
			all[i][2] = bag.getAlbum();
			all[i][3] = bag.getSdate();
			all[i][4] = bag.getLink();
			all[i][5] = bag.getWriter();
		}

		table = new JTable(all, header);
		table.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {

				int rowNo = table.getSelectedRow();

				Object song = table.getModel().getValueAt(rowNo, 0);
				Object singer = table.getModel().getValueAt(rowNo, 1);
				Object album = table.getModel().getValueAt(rowNo, 2);
				Object sdate = table.getModel().getValueAt(rowNo, 3);
				Object link = table.getModel().getValueAt(rowNo, 4);
				Object writer = table.getModel().getValueAt(rowNo, 5);
//				JOptionPane.showMessageDialog(table, song + " " + singer + " " + album + " " + sdate + " " + link + " " + writer);
				t1.setText(song + " || " + singer + " || " + album + " || " + sdate + " || " + link + " || " + writer);
				
				if (Desktop.isDesktopSupported()) {
					Desktop desktop = Desktop.getDesktop();
					try {
						URI uri = new URI((String) link);
						desktop.browse(uri);
					} catch (IOException ex) {
		                ex.printStackTrace();
		            } catch (URISyntaxException ex) {
		                ex.printStackTrace();
		            }
					
				}
				
			}
		});
		JScrollPane scrollPane = new JScrollPane(table); // ���̺� ���� ���� ( ==> ���� : MemberUI3)
		panel.add(scrollPane);
		scrollPane.setPreferredSize(new Dimension(600, 500));

		JButton btnNewButton = new JButton("�߶��");
		btnNewButton.setBounds(30, 140, 117, 29);
		f.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("����");
		btnNewButton_1.setBounds(171, 140, 117, 29);
		f.getContentPane().add(btnNewButton_1);

		JButton btnNewButton_1_1 = new JButton("�ε�");
		btnNewButton_1_1.setBounds(311, 140, 117, 29);
		f.getContentPane().add(btnNewButton_1_1);

		JButton btnNewButton_1_1_1 = new JButton("�˼�");
		btnNewButton_1_1_1.setBounds(454, 140, 117, 29);
		f.getContentPane().add(btnNewButton_1_1_1);

		JButton btnNewButton_2 = new JButton("+");
		btnNewButton_2.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		btnNewButton_2.setBounds(593, 140, 52, 29);
		f.getContentPane().add(btnNewButton_2);

		JButton btnNewButton_1_1_1_1 = new JButton("�˻�");
		btnNewButton_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel.remove(scrollPane);
				panel.repaint();

				// JPanel panel = new JPanel();
				// panel.setBounds(30, 228, 615, 516);
				// f.getContentPane().add(panel);

				String singer3 = t7.getText();

				String[] header = { "�뷡", "����", "�ٹ���", "�߸���", "��ũ", "�۾���" };
				IndiAddDAO dao = new IndiAddDAO();
				ArrayList<IndiAddVO> one = dao.one(singer3);
				// System.out.println(one.size());
				Object[][] all = new Object[one.size()][6];
				table = new JTable(all, header);
				for (int i = 0; i < one.size(); i++) {
					IndiAddVO bag = one.get(i);
					all[i][0] = bag.getSong();
					all[i][1] = bag.getSinger();
					all[i][2] = bag.getAlbum();
					all[i][3] = bag.getSdate();
					all[i][4] = bag.getLink();
					all[i][5] = bag.getWriter();
				}

				JScrollPane scrollPane = new JScrollPane(table);
				scrollPane.setPreferredSize(new Dimension(600, 500));
				panel.add(scrollPane);
				panel.updateUI();
				table.addMouseListener(new MouseAdapter() {

					@Override
					public void mouseClicked(MouseEvent e) {

						int rowNo = table.getSelectedRow();

						Object song = table.getModel().getValueAt(rowNo, 0);
						Object singer = table.getModel().getValueAt(rowNo, 1);
						Object album = table.getModel().getValueAt(rowNo, 2);
						Object sdate = table.getModel().getValueAt(rowNo, 3);
						Object link = table.getModel().getValueAt(rowNo, 4);
						Object writer = table.getModel().getValueAt(rowNo, 5);
//						JOptionPane.showMessageDialog(table, song + " " + singer + " " + album + " " + sdate + " " + link + " " + writer);
						t1.setText(song + " || " + singer + " || " + album + " || " + sdate + " || " + link + " || " + writer);
						
						if (Desktop.isDesktopSupported()) {
							Desktop desktop = Desktop.getDesktop();
							try {
								URI uri = new URI((String) link);
								desktop.browse(uri);
							} catch (IOException ex) {
				                ex.printStackTrace();
				            } catch (URISyntaxException ex) {
				                ex.printStackTrace();
				            }
							
						}
						
					}
				});
				
			}
		});
		btnNewButton_1_1_1_1.setFont(new Font("Lucida Grande", Font.BOLD, 15));
		btnNewButton_1_1_1_1.setBounds(540, 78, 117, 29);
		f.getContentPane().add(btnNewButton_1_1_1_1);

		f.setVisible(true);

	}
}